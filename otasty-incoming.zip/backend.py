"""
SwingDesk Backend — Solo Swing Trading System
FastAPI + SQLite + Alpaca Paper Trading
Run: uvicorn backend:app --host 0.0.0.0 --port 8888 --reload
"""

import sqlite3, json, math, os
from datetime import datetime, timedelta
from typing import Optional
from contextlib import contextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# ── CONFIG ────────────────────────────────────────────────────────────────────
ALPACA_KEY    = os.getenv("ALPACA_API_KEY", "YOUR_KEY_HERE")
ALPACA_SECRET = os.getenv("ALPACA_SECRET_KEY", "YOUR_SECRET_HERE")
ALPACA_URL    = "https://paper-api.alpaca.markets"   # paper
POLYGON_KEY   = os.getenv("POLYGON_API_KEY", "YOUR_POLYGON_KEY")

ACCOUNT_SIZE  = 52340.00
MAX_RISK_PCT  = 1.0          # % of account risked per trade
MAX_POSITIONS = 6
DAILY_LOSS_LIMIT = ACCOUNT_SIZE * 0.02   # 2% = circuit breaker
MONTHLY_DD_LIMIT = ACCOUNT_SIZE * 0.06  # 6%
EARNINGS_BLACKOUT_DAYS = 21
MIN_RR_RATIO  = 2.0

DB_PATH = "swingdesk.db"

# ── DATABASE ──────────────────────────────────────────────────────────────────
def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS trades (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol      TEXT NOT NULL,
            direction   TEXT NOT NULL,        -- LONG / SHORT
            setup       TEXT NOT NULL,        -- EMA Pullback, Bull Flag, etc
            entry_price REAL,
            stop_price  REAL,
            target_price REAL,
            shares      INTEGER,
            risk_dollars REAL,
            rr_ratio    REAL,
            status      TEXT DEFAULT 'open',  -- open / closed / cancelled
            exit_price  REAL,
            pnl         REAL,
            r_multiple  REAL,
            notes       TEXT,
            opened_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            closed_at   DATETIME,
            broker_order_id TEXT
        );

        CREATE TABLE IF NOT EXISTS signals (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol      TEXT,
            signal_type TEXT,   -- bull / bear / watch
            setup       TEXT,
            description TEXT,
            score       REAL,
            acted_on    INTEGER DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS daily_stats (
            date        TEXT PRIMARY KEY,
            realized_pnl REAL DEFAULT 0,
            unrealized_pnl REAL DEFAULT 0,
            trades_taken INTEGER DEFAULT 0,
            circuit_breaker_triggered INTEGER DEFAULT 0
        );
        """)

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

# ── MODELS ────────────────────────────────────────────────────────────────────
class SizeRequest(BaseModel):
    entry: float
    stop: float
    target: float
    account_size: Optional[float] = None
    risk_pct: Optional[float] = None

class TradeRequest(BaseModel):
    symbol: str
    direction: str           # LONG / SHORT
    setup: str
    entry_price: float
    stop_price: float
    target_price: float
    shares: int
    risk_dollars: float
    rr_ratio: float
    notes: Optional[str] = ""

class CloseRequest(BaseModel):
    trade_id: int
    exit_price: float
    notes: Optional[str] = ""

# ── APP ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="SwingDesk", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# ── POSITION SIZER ────────────────────────────────────────────────────────────
@app.post("/api/size")
def calculate_size(req: SizeRequest):
    """Core position sizing — risk-first math."""
    acct   = req.account_size or ACCOUNT_SIZE
    rpct   = req.risk_pct or MAX_RISK_PCT
    risk_d = acct * (rpct / 100)
    per_sh = abs(req.entry - req.stop)

    if per_sh == 0:
        raise HTTPException(400, "Entry and stop cannot be equal")

    shares   = math.floor(risk_d / per_sh)
    pos_size = shares * req.entry
    gain     = shares * abs(req.target - req.entry)
    rr       = abs(req.target - req.entry) / per_sh

    checks = {
        "rr_passes":        rr >= MIN_RR_RATIO,
        "risk_ok":          risk_d <= acct * 0.03,
        "position_size_ok": pos_size <= acct * 0.40,
    }

    return {
        "shares":        shares,
        "risk_dollars":  round(risk_d, 2),
        "position_size": round(pos_size, 2),
        "max_gain":      round(gain, 2),
        "rr_ratio":      round(rr, 2),
        "pct_of_account": round(pos_size / acct * 100, 1),
        "checks":        checks,
        "approved":      all(checks.values())
    }

# ── RISK GATE ─────────────────────────────────────────────────────────────────
@app.get("/api/risk-gate")
def risk_gate():
    """Before any new trade — check all limits."""
    today = datetime.now().date().isoformat()
    with get_db() as db:
        row = db.execute(
            "SELECT * FROM daily_stats WHERE date=?", (today,)
        ).fetchone()
        open_count = db.execute(
            "SELECT COUNT(*) as c FROM trades WHERE status='open'"
        ).fetchone()["c"]

    day_pnl = row["realized_pnl"] if row else 0.0
    cb_hit  = row["circuit_breaker_triggered"] if row else 0

    return {
        "circuit_breaker_active": bool(cb_hit),
        "daily_loss":            round(day_pnl, 2),
        "daily_loss_limit":      round(-DAILY_LOSS_LIMIT, 2),
        "daily_limit_ok":        day_pnl > -DAILY_LOSS_LIMIT,
        "open_positions":        open_count,
        "max_positions":         MAX_POSITIONS,
        "positions_ok":          open_count < MAX_POSITIONS,
        "can_trade":             not cb_hit and open_count < MAX_POSITIONS and day_pnl > -DAILY_LOSS_LIMIT
    }

# ── TRADE EXECUTION (PAPER) ───────────────────────────────────────────────────
@app.post("/api/trade/enter")
def enter_trade(req: TradeRequest):
    """Record trade + submit to Alpaca paper (or simulate if no key)."""
    gate = risk_gate()
    if not gate["can_trade"]:
        raise HTTPException(400, f"Risk gate blocked: {gate}")

    # Submit to Alpaca paper
    broker_id = _submit_alpaca_order(req)

    with get_db() as db:
        cursor = db.execute("""
            INSERT INTO trades
              (symbol, direction, setup, entry_price, stop_price,
               target_price, shares, risk_dollars, rr_ratio, notes, broker_order_id)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
        """, (req.symbol, req.direction, req.setup, req.entry_price,
              req.stop_price, req.target_price, req.shares,
              req.risk_dollars, req.rr_ratio, req.notes, broker_id))
        trade_id = cursor.lastrowid

        # Ensure daily_stats row
        db.execute("""
            INSERT OR IGNORE INTO daily_stats (date) VALUES (?)
        """, (datetime.now().date().isoformat(),))
        db.execute("""
            UPDATE daily_stats SET trades_taken = trades_taken + 1
            WHERE date = ?
        """, (datetime.now().date().isoformat(),))

    return {
        "status":    "submitted",
        "trade_id":  trade_id,
        "broker_id": broker_id,
        "symbol":    req.symbol,
        "shares":    req.shares,
        "entry":     req.entry_price,
        "stop":      req.stop_price,
        "target":    req.target_price
    }

@app.post("/api/trade/close")
def close_trade(req: CloseRequest):
    """Close a position, calculate P&L in R-multiples."""
    with get_db() as db:
        trade = db.execute(
            "SELECT * FROM trades WHERE id=?", (req.trade_id,)
        ).fetchone()
        if not trade:
            raise HTTPException(404, "Trade not found")
        if trade["status"] != "open":
            raise HTTPException(400, "Trade already closed")

        direction = trade["direction"]
        if direction == "LONG":
            pnl = (req.exit_price - trade["entry_price"]) * trade["shares"]
        else:
            pnl = (trade["entry_price"] - req.exit_price) * trade["shares"]

        per_sh_risk = abs(trade["entry_price"] - trade["stop_price"])
        r_multiple  = (pnl / trade["shares"]) / per_sh_risk if per_sh_risk > 0 else 0

        db.execute("""
            UPDATE trades SET status='closed', exit_price=?, pnl=?,
              r_multiple=?, notes=?, closed_at=CURRENT_TIMESTAMP
            WHERE id=?
        """, (req.exit_price, round(pnl, 2), round(r_multiple, 2),
              req.notes, req.trade_id))

        db.execute("""
            UPDATE daily_stats SET realized_pnl = realized_pnl + ?
            WHERE date = ?
        """, (round(pnl, 2), datetime.now().date().isoformat()))

    return {
        "trade_id":   req.trade_id,
        "pnl":        round(pnl, 2),
        "r_multiple": round(r_multiple, 2),
        "outcome":    "win" if pnl > 0 else "loss"
    }

# ── POSITIONS & JOURNAL ───────────────────────────────────────────────────────
@app.get("/api/positions")
def get_positions():
    with get_db() as db:
        rows = db.execute(
            "SELECT * FROM trades WHERE status='open' ORDER BY opened_at DESC"
        ).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/journal")
def get_journal(limit: int = 50):
    with get_db() as db:
        rows = db.execute("""
            SELECT * FROM trades WHERE status='closed'
            ORDER BY closed_at DESC LIMIT ?
        """, (limit,)).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/stats")
def get_stats():
    """30-day performance summary."""
    cutoff = (datetime.now() - timedelta(days=30)).isoformat()
    with get_db() as db:
        rows = db.execute("""
            SELECT pnl, r_multiple FROM trades
            WHERE status='closed' AND closed_at > ?
        """, (cutoff,)).fetchall()

    if not rows:
        return {"trades":0,"win_rate":0,"avg_rr":0,"net_pnl":0}

    wins    = [r for r in rows if r["pnl"] > 0]
    net_pnl = sum(r["pnl"] for r in rows)
    avg_rr  = sum(r["r_multiple"] for r in rows) / len(rows)

    return {
        "trades":    len(rows),
        "wins":      len(wins),
        "losses":    len(rows) - len(wins),
        "win_rate":  round(len(wins) / len(rows) * 100, 1),
        "avg_rr":    round(avg_rr, 2),
        "net_pnl":   round(net_pnl, 2),
        "best_trade": round(max(r["pnl"] for r in rows), 2),
        "worst_trade": round(min(r["pnl"] for r in rows), 2)
    }

# ── SCANNER (Pre-market) ──────────────────────────────────────────────────────
UNIVERSE = [
    "AAPL","MSFT","NVDA","AMD","META","GOOGL","AMZN","TSLA",
    "JPM","GS","BAC","XOM","CVX","LLY","UNH","SPY","QQQ"
]

@app.get("/api/scan")
def run_scanner():
    """
    Pre-market scanner — checks each symbol against setup criteria.
    In production: pull real candles from Polygon, compute EMAs, RSI, volume.
    Here: returns simulated scored results for demo.
    """
    import random
    results = []
    for sym in UNIVERSE:
        score  = random.randint(40, 100)
        rsi    = random.randint(35, 72)
        vol_vs = random.uniform(0.8, 2.2)
        setup  = random.choice(["EMA Pullback","Bull Flag","S/R Bounce","No Setup"])
        earn   = random.randint(5, 90)
        if setup == "No Setup" or earn < EARNINGS_BLACKOUT_DAYS:
            continue
        results.append({
            "symbol":     sym,
            "setup":      setup,
            "score":      score,
            "rsi":        rsi,
            "vol_ratio":  round(vol_vs, 2),
            "earnings_days_away": earn,
            "signal_type": "bull" if rsi < 60 else "watch"
        })
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:10]

# ── SIGNALS ───────────────────────────────────────────────────────────────────
@app.get("/api/signals")
def get_signals(limit: int = 20):
    with get_db() as db:
        rows = db.execute("""
            SELECT * FROM signals ORDER BY created_at DESC LIMIT ?
        """, (limit,)).fetchall()
    return [dict(r) for r in rows]

# ── ALPACA BRIDGE ─────────────────────────────────────────────────────────────
def _submit_alpaca_order(req: TradeRequest) -> str:
    """Submit limit order + bracket stop to Alpaca paper."""
    try:
        import urllib.request
        payload = json.dumps({
            "symbol":        req.symbol,
            "qty":           str(req.shares),
            "side":          req.direction.lower(),
            "type":          "limit",
            "limit_price":   str(req.entry_price),
            "time_in_force": "day",
            "order_class":   "bracket",
            "stop_loss":     {"stop_price": str(req.stop_price)},
            "take_profit":   {"limit_price": str(req.target_price)}
        }).encode()

        request = urllib.request.Request(
            f"{ALPACA_URL}/v2/orders",
            data=payload,
            method="POST",
            headers={
                "APCA-API-KEY-ID":     ALPACA_KEY,
                "APCA-API-SECRET-KEY": ALPACA_SECRET,
                "Content-Type":        "application/json"
            }
        )
        with urllib.request.urlopen(request, timeout=5) as resp:
            data = json.loads(resp.read())
            return data.get("id", "sim-" + datetime.now().strftime("%H%M%S"))
    except Exception as e:
        # Simulate if no real key configured
        return f"sim-{req.symbol}-{datetime.now().strftime('%H%M%S')}"

# ── STARTUP ───────────────────────────────────────────────────────────────────
@app.on_event("startup")
def startup():
    init_db()

@app.get("/api/health")
def health():
    return {"status": "ok", "time": datetime.now().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend:app", host="0.0.0.0", port=8888, reload=True)
