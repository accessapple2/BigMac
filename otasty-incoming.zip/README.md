# SwingDesk — Solo Trading System

## Stack
- **Frontend**: index.html (pure HTML/JS, TradingView Lightweight Charts)
- **Backend**: backend.py (FastAPI + SQLite)
- **Scanner**: scanner.py (pre-market signal generation)
- **Broker**: Alpaca Paper (bracket orders with stop + target)
- **Data**: Polygon.io (candles, options)

## Setup
```bash
pip install -r requirements.txt

export ALPACA_API_KEY=your_key
export ALPACA_SECRET_KEY=your_secret
export POLYGON_API_KEY=your_key

# Start backend
python backend.py

# Open frontend
open index.html

# Run scanner (pre-market, ~8am)
python scanner.py
```

## API Endpoints
| Method | Route | Purpose |
|--------|-------|---------|
| POST | /api/size | Position sizing calculator |
| GET | /api/risk-gate | Pre-trade risk check |
| POST | /api/trade/enter | Submit trade + Alpaca bracket order |
| POST | /api/trade/close | Close position, log P&L |
| GET | /api/positions | Open positions |
| GET | /api/journal | Closed trade history |
| GET | /api/stats | 30-day performance |
| GET | /api/scan | Pre-market scanner results |
| GET | /api/signals | Signal feed |

## Risk Rules (Hardcoded)
- Max 1% account risk per trade
- Max 6 open positions
- 2% daily loss = circuit breaker
- 6% monthly drawdown = halt
- Earnings blackout: 21 days before

## Broker Order Flow
1. User sets entry/stop/target in planner
2. Backend sizes shares via /api/size
3. Risk gate checked via /api/risk-gate
4. Preview modal shown with full order details
5. User confirms → /api/trade/enter
6. Bracket order submitted to Alpaca (limit + stop + target OCO)
7. Trade logged to SQLite with broker order ID
